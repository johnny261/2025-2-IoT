#pragma once

#include <string>

using namespace std;


// WiFi credentials
const char *SSID = "IoT";
const char *PASSWORD = "1245678h";

// ------------------------- MQTT Network ------------------------- //
const string BROKER = "192.168.43.55";

// ----------- thing-001 (self - ESP32-PIR)

// MQTT settings
const string ID_PIR = "thing-001";

// ----------- thing-002 (self - ESP32-ALARM)

// I/O config
// Lamps
#define LIGHT_PIN 2
// Buzzer
#define BUZZER_PIN 5

// MQTT settings
const string ID = "thing-002";
const string CLIENT_NAME = ID + "_ESP32-ALARM";

// Topics
const string TOPIC1 = ID_PIR + "/home/store/sensors/presence/pir";
const string TOPIC2 = ID + "/home/house/actuators/lamps/lamp1";

// ----------- iot-server (control)
// No se ha implementado aun